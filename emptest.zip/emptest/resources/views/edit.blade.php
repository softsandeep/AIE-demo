<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- Styles -->        
    </head>
    <body> 
	 @if(\Session::has('success'))
	 <h3>{!! \Session::get('success') !!}</h3>
	 @endif
	 <a href="{{url('/list-employee')}}" class="btn btn-primary" style="float: right;">Employee List</a>
    <form action="{{url('/update')}}" method="post">
    	@csrf()
		  <div class="form-group">
		    <label for="name">Name:</label>
		    <input type="text" class="form-control" id="name" name="name" value="{{$employeeData->name}}" required="">
		  </div>
		  <div class="form-group">
		    <label for="age">Age:</label>
		    <input type="text" class="form-control" id="age" name="age" value="{{$employeeData->age}}" required="">
		  </div>
		  <div class="form-group">
		    <label for="doj">DOJ:</label>
		    <input type="text" class="form-control" id="doj" name="doj" value="{{$employeeData->doj}}" required="">
		  </div>
		  <input type="hidden" name="id" value="{{$employeeData->id}}">
		  <button type="submit" class="btn btn-primary">Submit</button>
	</form>
    </body>
</html>
