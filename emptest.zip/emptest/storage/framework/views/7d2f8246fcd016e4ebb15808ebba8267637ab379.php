<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- Styles -->
        
    </head>
    <body>
          
             
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col">Age</th>
                      <th scope="col">doj</th>
                      <th scope="col">action</th>
                    </tr>
                  </thead>
                  <tbody>
                   <?php $__currentLoopData = $employeeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row">#</th>
                      <td><?php echo e($row->name); ?></td>
                      <td><?php echo e($row->age); ?></td>
                      <td><?php echo e($row->doj); ?></td>
                      <td>
                          <a href="<?php echo e(url('/edit-employee/'.$row->id)); ?>">edit</a>
                      </td>
                    </tr>
                    <<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\emptest\resources\views/welcome.blade.php ENDPATH**/ ?>