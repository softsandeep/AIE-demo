<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use Redirect;

class EmployeeController extends Controller
{
    public function index(){
    	$employeeData = Employee::all();
    	return view('welcome', compact('employeeData'));
    }

    public function edit($id){
    	$employeeData = Employee::where('id', $id)->first();
    	return view('edit', compact('employeeData'));
    }

     public function update(Request $request){

     	$this->validate($request, [
     		'name'=>'required',
     		'age'=>'required',
     		'doj'=>'required'
     	]);
    	$employeeData = Employee::find($request->id);
    	$employeeData->update([
    		'name'=>$request->name,
    		'age'=> $request->age,
    		'doj'=>$request->doj
    	]);
		return \Redirect::back()->with('success', 'Updated successfully!');
    }
}
